const isAuthedUser = () => Boolean(Math.ceil(Math.random() * 10) % 2);
const isAdminAuthed = () => Boolean(Math.ceil(Math.random() * 10) % 2);